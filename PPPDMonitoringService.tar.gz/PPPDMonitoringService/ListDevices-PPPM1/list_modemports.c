#include <stdio.h> 
#include <string.h>
#include <dirent.h> 
  
int main(void) 
{ 
    struct dirent *de;  // Pointer for directory entry 
    char port_list[7][10],temp[10];;
    int count=0,i,j;
  
    // opendir() returns a pointer of DIR type.  
      DIR *dr = opendir("/sys/bus/usb-serial/drivers/qcserial"); 
  
  
    if (dr == NULL)  // opendir returns NULL if couldn't open directory 
    { 
        printf("Could not open current directory" ); 
        return 0; 
    } 
  
    // Refer http://pubs.opengroup.org/onlinepubs/7990989775/xsh/readdir.html 
    // for readdir() 
    while ((de = readdir(dr)) != NULL){
		if (strstr(de->d_name,"ttyUSB") != NULL){
		strncpy(port_list[count],de->d_name,sizeof("ttyUSB")+2);
            	//printf("pointer name %s\n", de->d_name); 
		printf(" Buffer content %s\n",port_list[count]);		
		printf("Count value %d\n",count);
		count++;
		}

	}
// the above result is not sorted in any order hence sorting the above result in ascending order below
	 for(i=0;i<=count;i++)
	      for(j=i+1;j<=count;j++){
		 if(strcmp(port_list[i],port_list[j])>0){
		    strcpy(temp,port_list[i]);
		    strcpy(port_list[i],port_list[j]);
		    strcpy(port_list[j],temp);
		 }
	      }
	printf("Order of Sorted Strings:"); // sorting in ascending order.
  	 for(i=0;i<=count;i++)
     	 puts(port_list[i]);

printf("I value is %d and count is %d \n",i,count);
	printf("Lowest Port is %s\n",port_list[1]);
	printf("Highest Port is %s\n",port_list[count]);
	printf("We have Following list %s\n",port_list);  
    closedir(dr);     
    return 0; 
} 
