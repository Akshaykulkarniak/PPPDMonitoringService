
/*****************************************************************************************************
 * AUTHOR : ASK
 * COMPANY : Syratron Technologies Pvt Ltd / Sierra Wireless
 * APPLICATION : PPPD-Monitoring  
 * DATE : 25/04/2020
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, 
 * copies of the Software
 ******************************************************************************************************/




#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <termios.h> // Serial Port
#include <sys/ioctl.h>  // I/O write/read
#include <signal.h> // For SIGKILL
#include "modm.h" // Custom
#include <syslog.h> // Syslog
#include <dirent.h> 


#define baudrate B115200
#define true 1
#define false 0
#define cmnt_pf 0


int ppp_flag=0;
int serial_fd;
static int port_flag=1;  // We have not known the AT Port,once it is known we will clear the flag with port_flag=0.
int flag=0;
char myportname[7][10];
char portname[7][100];
char value[10];
char cmd0[200];
char cmd1[100];
char Ppid[10];
int ind;
int low_ind;//Stores Lowest port Index
int ppp_num;
modem_mgt modem_config;
void Set_Serial_Port(void);


/*----------###########################################  ListQCDevices START ###############################################--------- */

int ListQCDevices(void) 
{
 
    struct dirent *de;  // Pointer for directory entry 
    char temp[10];;
    int count=0,i,j,k=0,l=0;

	sleep(10);  
    // opendir() returns a pointer of DIR type.  
      DIR *dr = opendir("/sys/bus/usb-serial/drivers/qcserial"); 
  
  
    if (dr == NULL)  // opendir returns NULL if couldn't open directory 
    { 
        printf("Could not open current directory" ); 
        return 0; 
    } 
  
    // Refer http://pubs.opengroup.org/onlinepubs/7990989775/xsh/readdir.html 
    // for readdir() 
    while ((de = readdir(dr)) != NULL){
		if (strstr(de->d_name,"ttyUSB") != NULL){
		strncpy(myportname[count],de->d_name,sizeof("ttyUSB")+2);
        #if cmnt_pf
 	   	//printf("pointer name %s\n", de->d_name); 
		printf(" Buffer content %s\n",myportname[count]);		
		printf("Count value %d\n",count);
	#endif
		printf(" Buffer content %s\n",myportname[count]);		
		printf("Count value %d\n",count);
		count++;
		}

	}
// the above result is not sorted in any order hence sorting the above result in ascending order below
	 for(i=0;i<=count-1;i++)
	      for(j=i+1;j<=count-1;j++){
		 if(strcmp(myportname[i],myportname[j])>0){
		    strcpy(temp,myportname[i]);
		    strcpy(myportname[i],myportname[j]);
		    strcpy(myportname[j],temp);
		 }
	      }
  
      #if cmnt_pf
	printf("Order of Sorted Strings:"); // sorting in ascending order.
  	 for(i=0;i<=count;i++)
     	 puts(myportname[i]);
	#endif

        #if cmnt_pf
printf("I value is %d and count is %d \n",i,count);
	#endif
	printf("Lowest Port is ##%s##\n",myportname[0]);
	printf("Highest Port is ##%s##\n",myportname[count-1]);  
    closedir(dr);     
low_ind=0;
ind=low_ind;
for (k=0;k<=count-1;k++)
{
sprintf(portname[k],"/dev/%s",myportname[l++]);
}
//====== Added on 14-09-2020 =====
if(count > 0) // Check if count / QC devices are available 
{
Start_PPPD();  // QC devices Available so starting / Initializing PPPD session
}
else
{
    return 0; // Returning back event handler
}
//===============================
} 

/*----------###########################################  ListQCDevices END ###############################################--------- */





/*----------###########################################  Check_Port START ###############################################--------- */


void Check_Port(char *Rspn)
{
char buff1[20]="\0";
//char state[1];

printf("#Inside buffer#:: %s\n",Rspn);
strncpy(buff1,Rspn,20);
char *buff = strstr(buff1,"OK");
printf("buff has %s\n",buff);
if (buff != NULL)
{
strncpy(value,buff,2);

printf("====PORT RESPONDED ##%s##====\n",value);
	if(strcmp(value,"OK") == 0)
	{
	printf("##FOUND AT-PORT##%s## and Index is =>%d<=\n",portname[ind-1],(ind-1));
	port_flag=0;
		}

}

}


/*----------###########################################  Check_Port END ###############################################--------- */


/*----------########################################### Set_Serial_Port START ###############################################--------- */

void Set_Serial_Port(void)
{

char KillCmd[100];

//Open the Serial Port
//printf("##PORT USED ###%s### ##\n",portname[ind-1]);
if(port_flag==1)
{
// Perform Port Settings  // Check if the /dev/ttyUSB file exists if Yes goahead to set the Stty else return from here
sprintf(cmd0,"stty -F %s ignbrk -brkint -icrnl -imaxbel -opost -onlcr -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke",portname[ind]);
printf("##CMD is %s##\n",cmd0);
system(cmd0);  // If this command fails then Modem has restarted so return from here after checking the result.
sleep(2);
printf("SEARCHING AT-PORT\n");
		if(ind <= 2)
		{
				
			printf("#IND-%d#\n",ind);
			serial_fd = open(portname[ind++],O_RDWR | O_NOCTTY);
		}
		/*else if (ind == 2)
		{
		
		ind=low_ind; 
		// CALL serial open 

		// IF WE HAVE AN UNKILLED PPPD session WE KILL IT HERE BEFORE RETRYING	
		//killdaemon();
		return;
		}
		*/
		else
		{

		//	strcpy(cmd2,"sudo killall /usr/sbin/pppd");
		//sprintf(cmd1,"/usr/sbin/pppd unit 0 %s &",portname[ind-1]);
			
		ind=low_ind;
		printf("IND set to Lower\n"); 
		// IF WE HAVE AN UNKILLED PPPD session WE KILL IT HERE BEFORE RETRYING	
		killdaemon();

	
		
		return;
		}
			

}
else
{
printf("AT-PORT IS KNOWN\n");
serial_fd = open(portname[ind-1],O_RDWR | O_NOCTTY);
}

	
		if(serial_fd < 0)
	{
		
		printf("Unable to open device %s \n",portname[ind-1]);
//		return serial_fd;
//========================================= Moved on 21-08-2020 =========================================
		if((ind>0) && (ind <=2))
			{
			// Lets kill the daemon with kill all and Port Number
			sprintf(KillCmd,"killall /usr/sbin/pppd unit 0 %s",portname[ind]);
			system(KillCmd);
			sleep(2);
			printf("Killall Executed");
				system("logger 'Killall Executed !!!!'");
			return;
			}

//=====================================================================================================
	}
	else
{
	printf("Device open with fd:%d\n",serial_fd);


		
		struct termios SerialPortSettings;	/* Create the structure                          */

		tcgetattr(serial_fd, &SerialPortSettings);	/* Get the current attributes of the Serial port */

		cfsetispeed(&SerialPortSettings,B115200); /* Set Read  Speed                       */
		cfsetospeed(&SerialPortSettings,B115200); /* Set Write Speed                       */

		SerialPortSettings.c_cflag &= ~PARENB;   /* Disables the Parity Enable bit(PARENB),So No Parity   */
		SerialPortSettings.c_cflag &= ~CSTOPB;   /* CSTOPB = 2 Stop bits,here it is cleared so 1 Stop bit */
		SerialPortSettings.c_cflag &= ~CSIZE;	 /* Clears the mask for setting the data size             */
		SerialPortSettings.c_cflag |=  CS8;      /* Set the data bits = 8                                 */
	
		SerialPortSettings.c_cflag &= ~CRTSCTS;       /* No Hardware flow Control                         */
		SerialPortSettings.c_cflag |= CREAD | CLOCAL; /* Enable receiver,Ignore Modem Control lines       */ 
		
		
		SerialPortSettings.c_iflag &= ~(IXON | IXOFF | IXANY);          /* Disable XON/XOFF flow control both i/p and o/p */
		SerialPortSettings.c_iflag &= ~(ICANON | ECHO | ECHOE | ISIG);  /* Non Cannonical mode                            */

		SerialPortSettings.c_oflag &= ~OPOST;/*No Output Processing*/

		// defining Timeout for reading 
		SerialPortSettings.c_cc[VMIN]  = 10;            // read doesn't block
		SerialPortSettings.c_cc[VTIME] = 0;            // 1 seconds read timeout

		if((tcsetattr(serial_fd,TCSANOW,&SerialPortSettings)) != 0) /* Set the attributes to the termios structure*/
		    printf("\n  ERROR ! in Setting attributes");
		else
			printf("\n");
        #if cmnt_pf
                    printf("\n  BaudRate = 115200 \n  StopBits = 1 \n  Parity   = none");
	#endif
}

}

/*----------###########################################  Set_Serial_Port END ###############################################--------- */


/*----------###########################################  Test_port Start ###############################################--------- */

void Test_port()
{
int bytes_avail,bytes;	
	char * buf1;
	char * resp1;
	int waiting_response = 1;

	Set_Serial_Port(); // Perform serial port settings
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 
//--------------------------------------------
	
	resp1 = malloc(sizeof(char*)*1000 + 1);

	buf1 = "AT\n";

//--------------------------------------------
	printf("\r\nCommand:: %s",buf1);
	bytes = write(serial_fd,buf1,strlen(buf1));
	printf("\r\nBytes Written:: %d\r\n",bytes);
int counter=0;
	while(waiting_response)
	{
		ioctl(serial_fd, FIONREAD, &bytes_avail);
		sleep(3);
		if(bytes_avail > 0)
			{
			waiting_response = 0;
			read(serial_fd,resp1,bytes_avail);
			printf("\r\nResponse:: %s\r\n",resp1);
			Check_Port(resp1); // Get the Response for command AT
			}
		else
			{
				if(counter == 3)
					{
					waiting_response=0;	
					}
			counter++;
			printf("\r\nBytes to Read:: %d\r\n",bytes_avail);	
			}	
	}
	memset(resp1,'\0',sizeof(resp1));
	//memset(buf,'\0',sizeof(buf));		
	close(serial_fd);
sleep (2);

		if(counter > 10)
		{
		printf("Lets Release the Port !!!!\n");
		}
return;

}

/*----------###########################################  Test_port END ###############################################--------- */





/*----------###########################################  ReleasePort START ###############################################--------- */

void ReleasePort()
{
int bytes;
char * buf1;
Set_Serial_Port(); // Perform serial port settings
tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 
buf1 = "+++";

	printf("\r\nRelase Port::##%s##\n",buf1);
	sleep (2);
	bytes = write(serial_fd,buf1,strlen(buf1));
	printf("\r\nBytes Written:: %d\r\n",bytes);
	sleep (2);
	close(serial_fd);
return;

}



/*----------###########################################  ReleasePort END ###############################################--------- */


/*----------########################################### InitConfig START ###############################################--------- */


void InitConfig()
{
	int bytes;
	char * buf0;
	char * buf1;
	char * buf2;
	char * buf3;
	Set_Serial_Port(); // Perform serial port settings
	if(serial_fd < 0)
{
printf("No such device named %s found\n",portname[ind]);

}
else
{

	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 

	buf0 = "AT+CFUN=1\r";
	buf1 = "AT+CREG=0\r";
	buf2 = "AT+CGREG=0\r";
	buf3 = "AT+CEREG=0\r";
	
	 #if cmnt_pf
	printf("\r\nInit-Command-1:: %s",buf0);
	#endif	
	bytes = write(serial_fd,buf0,strlen(buf0));
        #if cmnt_pf
	printf("\r\nBytes Written:: %d\r\n",bytes);
	#endif	
	
	sleep (3);
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer
        #if cmnt_pf
	printf("\r\nInit-Command-1:: %s",buf1);
	#endif	
	bytes = write(serial_fd,buf1,strlen(buf1));
        #if cmnt_pf
	printf("\r\nBytes Written:: %d\r\n",bytes);
	#endif	
	
	sleep (3);
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 
	
        #if cmnt_pf
	printf("\r\nInit-Command-2:: %s",buf2);
	#endif	
	bytes = write(serial_fd,buf2,strlen(buf2));
        #if cmnt_pf
	printf("\r\nBytes Written:: %d\r\n",bytes);
	#endif	

	
	sleep (3);
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 

	
        #if cmnt_pf
	printf("\r\nInit-Command-3:: %s",buf3);
	#endif	
	bytes = write(serial_fd,buf3,strlen(buf3));
        #if cmnt_pf
	printf("\r\nBytes Written:: %d\r\n",bytes);
	#endif	
		
	close(serial_fd);
}
}

/*----------########################################### InitConfig END ###############################################--------- */




/*----------########################################### GetNwState START ###############################################--------- */


void GetNwState()
{
	int bytes_avail;
	int bytes;	
	char * buf1;
	char * resp1;
	int waiting_response = 1;

	Set_Serial_Port(); // Perform serial port settings
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 
//--------------------------------------------
	
	resp1 = malloc(sizeof(char*)*1000 + 1);

	buf1 = "AT+CREG?\r";

//--------------------------------------------
        #if cmnt_pf
	printf("\r\nCommand:: %s",buf1);
	#endif	
	bytes = write(serial_fd,buf1,strlen(buf1));
        #if cmnt_pf
	printf("\r\nBytes Written:: %d\r\n",bytes);
	#endif	
int counter=0;
	while(waiting_response)
	{
		ioctl(serial_fd, FIONREAD, &bytes_avail);
		sleep(3);
		if(bytes_avail > 0)
			{
			waiting_response = 0;
			read(serial_fd,resp1,bytes_avail);
        		#if cmnt_pf
			printf("\r\nResponse:: %s\r\n",resp1);
			#endif	
			Read_NtwRegState(resp1,&modem_config); // Get the Registration State
//		printf("NtW Reg state is %s \n",modem_config.nwstate);// Need to handle the Error atleast a logger is necesssary
			}
		else
			{
				if(counter == 20)
					{
					waiting_response=0;	
					}
			counter++;
        		#if cmnt_pf
			printf("Counter Value is %d\n",counter);
			printf("\r\n***************************************\r\n");
			printf("\r\nBytes to Read:: %d\r\n",bytes_avail);	
			printf("\r\n***************************************\r\n");
			#endif	
			}	
	}
	memset(resp1,'\0',sizeof(resp1));
	//memset(buf,'\0',sizeof(buf));		
	close(serial_fd);
sleep (2);

		if(counter > 20)
		{
		printf("Lets Release the Port !!!!\n");
		 ReleasePort(); // Sending +++ to release the AT Port
		}
}



/*----------########################################### GetNwState END ###############################################--------- */




/*----------########################################### GetOperName START ###############################################--------- */


void GetOperName()
{
	int bytes_avail,bytes;	
	char * buf1;
	char * resp1;
	int waiting_response = 1;

	Set_Serial_Port(); // Perform serial port settings
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 
	sleep(2);
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 

//--------------------------------------------
	
	resp1 = malloc(sizeof(char*)*100 + 1);

	buf1 = "AT+COPS?\r";
//--------------------------------------------
        		#if cmnt_pf
	printf("\r\nCommand:: %s",buf1);
			#endif
	bytes = write(serial_fd,buf1,strlen(buf1));
        		#if cmnt_pf
	printf("\r\nBytes Written:: %d\r\n",bytes);
			#endif

	while(waiting_response)
	{
		sleep(3);
		ioctl(serial_fd, FIONREAD, &bytes_avail);
		if(bytes_avail > 0)
			{
			waiting_response = 0;
			read(serial_fd,resp1,bytes_avail);
        		#if cmnt_pf
			printf("\r\nResponse:: %s\r\n",resp1);
			#endif
            		 Get_OperInfoRspn(resp1,&modem_config); // Read the Operator Info
		//	printf("Network Operator Name is %s \n",modem_config.oper_name);
			}
		else
			{
			printf("\r\n***************************************\r\n");
			printf("\r\nBytes to Read:: %d\r\n",bytes_avail);	
			}	
	}
	memset(resp1,'\0',sizeof(resp1));
	//memset(buf,'\0',sizeof(buf));		
	close(serial_fd);
}


/*----------########################################### GetOperName END ###############################################--------- */


/*----------########################################### GetSignalStrength START ###############################################--------- */


void GetSignalStrength()
{
	int bytes_avail,bytes;	
	char * buf1;
	char * resp1;
	int waiting_response = 1;

	Set_Serial_Port(); // Perform serial port settings
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 
	sleep(2);
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 

//--------------------------------------------
	
	resp1 = malloc(sizeof(char*)*100 + 1);

	buf1 = "AT+CSQ\r";
//--------------------------------------------
        		#if cmnt_pf
	printf("\r\nCommand:: %s",buf1);
			#endif
	bytes = write(serial_fd,buf1,strlen(buf1));
        		#if cmnt_pf
	printf("\r\nBytes Written:: %d\r\n",bytes);
			#endif

	while(waiting_response)
	{
		sleep(3);
		ioctl(serial_fd, FIONREAD, &bytes_avail);
		if(bytes_avail > 0)
			{
			waiting_response = 0;
			read(serial_fd,resp1,bytes_avail);
        		#if cmnt_pf
			printf("\r\nResponse:: %s\r\n",resp1);
			#endif
            		 Read_Signal_Strength(resp1,&modem_config); // Read the Operator Info
		//	printf("Network Operator Name is %s \n",modem_config.oper_name);
			}
		else
			{
			printf("\r\n***************************************\r\n");
			printf("\r\nBytes to Read:: %d\r\n",bytes_avail);	
			}	
	}
	memset(resp1,'\0',sizeof(resp1));
	//memset(buf,'\0',sizeof(buf));		
	close(serial_fd);
}


/*----------########################################### GetSignalStrength END ###############################################--------- */




/*----------########################################### killdaemon START ###############################################--------- */

int killdaemon()
{
    int ret=-1;
	int i=0;
	if (ppp_flag == 1)
{
        printf("PID is ##%s###\n", Ppid);

        printf("Killing the daemon\n");
        while(ret==-1)
	{
	ret=kill(atoi(Ppid),SIGKILL);
	sleep(1);
	i++;
	if(i==10)
	{
	system("logger 'Kill retries exceeded Exiting Killdaemon !!'");
	break;
	}
	}	

	system("logger 'PPPD Killed !!!!'");
	//sleep(2);
	ppp_flag=0;  
	port_flag=1; 
	ind=0;
 return;
}
else
{
	system("logger 'PPPD is Not Running'");

}
  

}

/*----------########################################### killdaemon END ###############################################--------- */




/*----------########################################### CopyPID START ###############################################--------- */

void CopyPID()
{
if (ppp_num == 1)
{
 FILE* ptr = fopen("/var/run/ppp1.pid","r");
   if (ptr==NULL)
    {
        printf("No PPP1.pid\n");
        return 0;
    }
    while (fscanf(ptr,"%s",Ppid)==1)
	printf("COPIED PID is ##%s##\n",Ppid);
	openlog("PPP-PID of detect1", LOG_PID, LOG_USER);
      syslog(LOG_INFO, "PID-Detect1 %s",Ppid);
        closelog();
}
else
{
   FILE* ptr = fopen("/var/run/ppp0.pid","r");
   if (ptr==NULL)
    {
        printf("No PPP0.pid\n");
        return 0;
    }
    while (fscanf(ptr,"%s",Ppid)==1)
        printf("PID is ##%s###\n",Ppid);

}

}





/*----------########################################### CopyPID END ###############################################--------- */

/*----------########################################### Check_ExistATPORT START ###############################################--------- */





int Check_ExistATPORT()
{
system("logger 'Checking tty-AT Port' ");

int ret_1=access(portname[ind-1],F_OK); // Check if the device /dev/ttyUSBX is available 
if(ret_1==0)
{
printf("ttyUSB-PORT Exists\n");
return 0;
}
else
{
printf("ttyUSB-PORT Not found\n");
return -1;
}
}

/*----------########################################### Check_ExistATPORT END ###############################################--------- */


/*----------########################################### Check_ExistPPP START ###############################################--------- */


int Check_ExistPPP()
{
int ret_1=access("/var/run/ppp0.pid",F_OK);
if(ret_1==0)
{
printf("ppp0 Exists\n");
sprintf(cmd1,"/usr/sbin/pppd unit 1 %s &",portname[ind-1]);
ppp_num=1;
return 0;
}
else
{
printf("No ppp0 found\n");
sprintf(cmd1,"/usr/sbin/pppd unit 0 %s &",portname[ind-1]);
ppp_num=0;
return 1;
}
}


/*----------########################################### Check_ExistPPP END ###############################################--------- */









/*----------########################################### GetOperID START ###############################################--------- */


void GetOpertorID()
{
	int bytes_avail,bytes;	
	char * buf1;
	char * resp1;
	int waiting_response = 1;

	Set_Serial_Port(); // Perform serial port settings
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 
//--------------------------------------------
	
	resp1 = malloc(sizeof(char*)*1000 + 1);

	buf1 = "AT+CRSM=176,28486,0,0,2\r";

//--------------------------------------------
        		#if cmnt_pf
	printf("\r\nCommand:: %s",buf1);
			#endif
	bytes = write(serial_fd,buf1,strlen(buf1));
        		#if cmnt_pf
	printf("\r\nBytes Written:: %d\r\n",bytes);
			#endif
int counter=0;
	while(waiting_response)
	{
		ioctl(serial_fd, FIONREAD, &bytes_avail);
		sleep(3);
		if(bytes_avail > 0)
			{
			waiting_response = 0;
			read(serial_fd,resp1,bytes_avail);
        		#if cmnt_pf
			printf("\r\nResponse:: %s\r\n",resp1);
			#endif
			Get_OperID(resp1,&modem_config); // Get the Operator ID
//printf("OperID value is : ####%s#### \n",modem_config.operID);

			}
		else
			{
				if(counter == 20)
					{
					waiting_response=0;	
					}
			counter++;
        		#if cmnt_pf
			printf("Counter Value is %d\n",counter);
			printf("\r\n***************************************\r\n");
			printf("\r\nBytes to Read:: %d\r\n",bytes_avail);	
			printf("\r\n***************************************\r\n");
			#endif
			}	
	}
	memset(resp1,'\0',sizeof(resp1));
	//memset(buf,'\0',sizeof(buf));		
	close(serial_fd);
}

/*----------########################################### GetOperID END ###############################################--------- */



/*----------########################################### GetAPN START ###############################################--------- */


void GetAPN(int simNum)
{
	int bytes_avail,bytes;	
	char * buf1;
	char * resp1;
	int waiting_response = 1;

	Set_Serial_Port(); // Perform serial port settings
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 
//--------------------------------------------
	
	resp1 = malloc(sizeof(char*)*1000 + 1);

	buf1 = "AT+CGDCONT?\r";

//--------------------------------------------
	printf("\r\nCommand:: %s",buf1);
	bytes = write(serial_fd,buf1,strlen(buf1));
	printf("\r\nBytes Written:: %d\r\n",bytes);
int counter=0;
	while(waiting_response)
	{
		ioctl(serial_fd, FIONREAD, &bytes_avail);
		sleep(3);
		if(bytes_avail > 0)
			{
			waiting_response = 0;
			read(serial_fd,resp1,bytes_avail);
			printf("\r\nResponse:: %s\r\n",resp1);
			Read_PdpCont(resp1,&modem_config,simNum);

			printf("PDP value is : %s \n",modem_config.pdpstate);

			}
		else
			{
				if(counter == 20)
					{
					waiting_response=0;	
					}
			counter++;
			printf("Counter Value is %d\n",counter);
			printf("\r\n***************************************\r\n");
			printf("\r\nBytes to Read:: %d\r\n",bytes_avail);	
			printf("\r\n***************************************\r\n");
			}	
	}
	memset(resp1,'\0',sizeof(resp1));
	//memset(buf,'\0',sizeof(buf));		
	close(serial_fd);
}


/*----------########################################### GetAPN END ###############################################--------- */




/*----------########################################### SetAPN START ###############################################--------- */

void SetAPN(int simNum)
{
int bytes;
char * buf1;
char * buf2;
Set_Serial_Port(); // Perform serial port settings
tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 
buf1 = "AT+CGDCONT=1\n";
			if(simNum == 1)
			{
				buf2 = "AT+CGDCONT=1,\"IPV4V6\",\"IOT.CRISRTIS.CO.IN\"\r"; // Vodafone APN
			}
			else if(simNum == 2)
			{
				buf2 = "AT+CGDCONT=1,\"IPV4V6\",\"CRISRTIS.COM\"\r"; // 14-09-2020 Airtel APN changed from CRIS1.COM to CRISRTIS.COM according to Pankaj's suggestion
			}

	printf("\r\nDelete APN ::##%s##\n",buf1);
	bytes = write(serial_fd,buf1,strlen(buf1));
	printf("\r\nBytes Written:: %d\r\n",bytes);
	sleep (5);

	printf("====> Setting Correct APN ::##%s##\n",buf2); 
	bytes = write(serial_fd,buf2,strlen(buf2));
	printf("\r\nBytes Written:: %d\r\n",bytes);
	close(serial_fd); // Close the Port FD

}
/*----------########################################### SetAPN END ###############################################--------- */





/*----------########################################### CheckSimState START ###############################################--------- */


void CheckSimState()
{
int bytes_avail,bytes;	
	char * buf1;
	char * resp1;
	int waiting_response = 1;

	Set_Serial_Port(); // Perform serial port settings
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 
	tcflush(serial_fd, TCIOFLUSH);   // Flush the old data in the rx buffer 
//--------------------------------------------
	resp1 = malloc(sizeof(char*)*1000 + 1);
	buf1 = "AT+CPIN?\r";
//--------------------------------------------
	printf("\r\nCommand:: %s",buf1);
	bytes = write(serial_fd,buf1,strlen(buf1));
	printf("\r\nBytes Written:: %d\r\n",bytes);
int counter=0;
		while(waiting_response)
	{
		ioctl(serial_fd, FIONREAD, &bytes_avail);
		sleep(3);
		if(bytes_avail > 0)
			{
			waiting_response = 0;
			read(serial_fd,resp1,bytes_avail);
			printf("\r\nResponse:: %s\r\n",resp1);
			Read_Sim_State(resp1,&modem_config);

			printf("SIM STATE is : %s \n",modem_config.simState);

			}
		else
			{
				if(counter == 20)
					{
					waiting_response=0;	
					}
			counter++;
			printf("Counter Value is %d\n",counter);
			printf("\r\n***************************************\r\n");
			printf("\r\nBytes to Read:: %d\r\n",bytes_avail);	
			printf("\r\n***************************************\r\n");
			}	
	}
	memset(resp1,'\0',sizeof(resp1));
	//memset(buf,'\0',sizeof(buf));		
	close(serial_fd);


}






/*----------########################################### CheckSimState END ###############################################--------- */



/*----------########################################### MAIN START ###############################################--------- */



int Start_PPPD()
{

/********************** Commented on 14-09-2020 **********************

ListQCDevices();
sleep(2);
**********************************************************************/

printf("Lets find AT Port\n");


while(port_flag == 1 )
{
Test_port(); //We will find out which is the AT Command port
}


printf("Entering Next Stage\n");
//portname = argv[1];
printf("Our Port is %s\n",portname[ind-1]);
int ret;   // Stores return value for killdaemon function
int simNum;  // Stores Sim Number
//int pingFlag;  // Stores Value of pingFlag to determine Operator and ping respective gateways
//char cmd1[100];
char cmd2[100];
char cmd3[100];
char cmd4[100]; 
char cmd5[100];
char cmd6[100];
char cmd7[100];
int indexer=0;




/*
strcpy(cmd0,"stty -F /dev/ttyUSB2 ignbrk -brkint -icrnl -imaxbel -opost -onlcr -isig -icanon -iexten -echo -echoe -echok -echoctl -echoke"); //Port settings
strcpy(cmd1,"/usr/sbin/pppd /dev/ttyUSB2 &"); // Initiate the PPPD Daemon
 */

strcpy(cmd2,"sudo killall /usr/sbin/pppd"); // Kill the existing PPPD process
strcpy(cmd3,"sudo echo Network Registration Failed  !!!! >> /home/rtis/PPPlogs.txt"); // Log the Registration failure


// Perform Port Settings



InitConfig(); // Perform Initial Configurations
sleep(2);
if(port_flag==1)
{

printf("No such device named %s found\n",portname[ind]);
system("logger 'PPP0 : /dev/ttyUSBx Device Not found'");

}
else
while (indexer==0)
{

		//pingFlag=0; // Flag Set to Default value
/*########################################### KILL PPPD DAEMON IF FOUND  #############################################*/
if(flag == 1)
{
ret = killdaemon();
if(ret == 0)
{
printf("PPPD daemon killed \n");
sleep (10);
ReleasePort(); // Sending +++ to release the AT Port
}
else
{
printf("No PPPD running \n");
return 0;
}
}


//------------------ Here Check Sim State
 
CheckSimState();
printf("#### Sim State is ####%s#### \n",modem_config.simState);
if(strcmp(modem_config.simState,"Present") == 0)
{
system("logger 'PPP0 : SIM_STATE : Present'");
sleep(5);
}
else
{
printf("Sim card is Not Inserted !!!!\n");
system("logger 'PPP0 : SIM_STATE : Absent'");
sleep(30);
continue;
}

//----------------- Here Check Sim State 

/*####################################### Check Signal Strength ########################################*/

GetSignalStrength();
printf("#### SignalStrength is ####%s#### \n",modem_config.sigStr);

/*#################################### Check Sim Registeration State  ####################################*/

GetNwState(); 
printf("#### Network Reg state is ####%s#### \n",modem_config.nwstate);


/*#################################### Sim Registered to Home Network ####################################*/

if(strcmp(modem_config.nwstate,"1") == 0)
{
system("logger 'PPP0 : NW_RG_STATE : Home-Network'");
sleep (2);
GetOpertorID();

/*#################################### Airtel Sim Registered to Home Network ####################################*/
if(strcmp(modem_config.operID,"0061") == 0 )
	{
		simNum=2;
		printf("Airtel Sim Present and is registered to Home Network\n");
		system("logger 'PPP0 : NW_OPER_INFO : Airtel'");
		strcpy(cmd4,"ip route add 10.64.65.103 dev ppp0"); // routing-1 for Airtel
		strcpy(cmd5,"ip route add 10.64.65.33 dev ppp0"); // routing-2 for Airtel
		strcpy(cmd6,"ip route add 203.176.113.66 dev ppp0"); // routing-3 for Airtel
		strcpy(cmd7,"ip route add 10.64.65.37 dev ppp0"); // routing-4 for Airtel
		GetAPN(simNum);
 		if (strcmp(modem_config.pdpstate,"CRISRTIS.COM") == 0) // 14-09-2020 Airtel APN changed from CRIS1.COM to CRISRTIS.COM according to Pankaj's suggestion
			{
				printf("#### APN is CRISRTIS.COM ####\n"); // 14-09-2020 Airtel APN changed from CRIS1.COM to CRISRTIS.COM according to Pankaj's suggestion
				system("logger 'PPP0 : NW_OPER_APN : CRISRTIS.COM'"); // 14-09-2020 Airtel APN changed from CRIS1.COM to CRISRTIS.COM according to Pankaj's suggestion
				Check_ExistPPP();
				sleep(2);
				system(cmd1);
				sleep(12);
				CopyPID();
				indexer=1;
				ppp_flag=1;
			//	break;
				return 0;
			}
		else		
			{
				printf("Incorrect APN Setting the APN\n");
				system("logger 'PPP0 : NW_OPER_APN : Incorrect APN found Setting Correct APN'");
				SetAPN(simNum);
				Check_ExistPPP();

				sleep(2);
				system(cmd1);
				sleep(12);
				CopyPID();
				indexer=1;
				ppp_flag=1;
				//break;
				return 0;
			} 
		//pingFlag=2; // Flag is 2 for Airtel
	}
/*#################################### Vodafone-IDEA Sim Registered to Home Network ####################################*/
else if(strcmp(modem_config.operID,"0056") == 0)
	{
		simNum=1;
		printf("Vodafone Sim Present and is registered to Home Network\n");
		system("logger 'PPP0 : NW_OPER_INFO : Vodafone'");
		strcpy(cmd4,"ip route add 10.64.65.102 dev ppp0"); // routing-1 for Vodafone
		strcpy(cmd5,"ip route add 10.64.65.34 dev ppp0"); // routing-2 for Vodafone
		strcpy(cmd6,"ip route add 203.176.113.85 dev ppp0"); // routing-3 for Vodafone
		strcpy(cmd7,"ip route add 10.64.65.37 dev ppp0"); // routing-4 for Vodafone
		GetAPN(simNum);
		if (strcmp(modem_config.pdpstate,"IOT.CRISRTIS.CO.IN") == 0)
			{
				printf("#### APN is IOT.CRISRTIS.CO.IN ####\n");
				system("logger 'PPP0 : NW_OPER_APN : IOT.CRISRTIS.CO.IN'");
				Check_ExistPPP();
				sleep(2);
				system(cmd1);
				sleep(12);
				CopyPID();
				indexer=1;
				ppp_flag=1;
			//	break;
				return 0;
			}
		else		
			{
				printf("Incorrect APN Setting the APN\n");
				system("logger 'PPP0 : NW_OPER_APN : Incorrect APN found Setting Correct APN'");
				SetAPN(simNum);
				Check_ExistPPP();
				sleep(2);
				system(cmd1);
				sleep(12);
				CopyPID();
				indexer=1;
				ppp_flag=1;
				//break;
				return 0;
			} 
		//pingFlag=1; // Flag is 1 for Vodafone



	}
}
/*#################################### Sim Registered to Roaming Network ####################################*/
else if(strcmp(modem_config.nwstate,"5") == 0)
{
printf("Modem is Registered to Roaming Network and state value is :%s:\n",modem_config.nwstate);
system("logger 'PPP0 : NW_RG_STATE : Roaming Network'");
sleep (2);
GetOpertorID();
/*#################################### Airtel Sim Registered to Roaming Network ####################################*/
if(strcmp(modem_config.operID,"0061") == 0)
{		
		simNum=2;
		printf("Airtel Sim Present and is registered to Roaming Network\n");	
		system("logger 'PPP0 : NW_OPER_INFO : Airtel'");
		strcpy(cmd4,"ip route add 10.64.65.103 dev ppp0"); // routing-1 for Airtel
		strcpy(cmd5,"ip route add 10.64.65.33 dev ppp0"); // routing-2 for Airtel
		strcpy(cmd6,"ip route add 203.176.113.66 dev ppp0"); // routing-3 for Airtel
		strcpy(cmd7,"ip route add 10.64.65.37 dev ppp0"); // routing-4 for Airtel
		GetAPN(simNum);
 		if (strcmp(modem_config.pdpstate,"CRISRTIS.COM") == 0) // 14-09-2020 Airtel APN changed from CRIS1.COM to CRISRTIS.COM according to Pankaj's suggestion
			{
				printf("#### APN is CRISRTIS.COM ####\n"); // 14-09-2020 Airtel APN changed from CRIS1.COM to CRISRTIS.COM according to Pankaj's suggestion
				system("logger 'PPP0 : NW_OPER_APN : CRISRTIS.COM'"); // 14-09-2020 Airtel APN changed from CRIS1.COM to CRISRTIS.COM according to Pankaj's suggestion
				Check_ExistPPP();
				sleep(2);
				system(cmd1);
				printf("#####BREAKING-LOOP######\n");
				sleep(12);
				CopyPID();
				indexer=1;
				ppp_flag=1;
			//	break;				
				
				return 0;
			}
		else		
			{
				printf("Incorrect APN Setting the APN\n");
				system("logger 'PPP0 : NW_OPER_APN : Incorrect APN found Setting Correct APN'");
				SetAPN(simNum);
				Check_ExistPPP();
				sleep(2);
				system(cmd1);
				printf("#####BREAKING-LOOP######\n");
				sleep(12);
				CopyPID();
				indexer=1;
				ppp_flag=1;
				//break;
				return 0;
			} 
		//pingFlag=2; // Flag is 2 for Airtel



}

/*#################################### Vodafone-IDEA Sim Registered to Roaming Network ####################################*/

else if(strcmp(modem_config.operID,"0056") == 0)
{
		simNum=1;
		printf("Vodafone Sim Present and is registered to Roaming Network\n");
		system("logger 'PPP0 : NW_OPER_INFO : Vodafone'");
		strcpy(cmd4,"ip route add 10.64.65.102 dev ppp0"); // routing-1 for Vodafone
		strcpy(cmd5,"ip route add 10.64.65.34 dev ppp0"); // routing-2 for Vodafone
		strcpy(cmd6,"ip route add 203.176.113.85 dev ppp0"); // routing-3 for Vodafone
		strcpy(cmd7,"ip route add 10.64.65.37 dev ppp0"); // routing-4 for Vodafone
		GetAPN(simNum);
		if (strcmp(modem_config.pdpstate,"IOT.CRISRTIS.CO.IN") == 0)
			{
				printf("#### APN is IOT.CRISRTIS.CO.IN ####\n");
				system("logger 'PPP0 : NW_OPER_APN : IOT.CRISRTIS.CO.IN'");
				Check_ExistPPP();

				sleep(2);
				system(cmd1);
				sleep(12);
				CopyPID();
				indexer=1;
				ppp_flag=1;
				//break;
				return 0;

			}
		else		
			{
				printf("Incorrect APN Setting the APN\n");
				system("logger 'PPP0 : NW_OPER_APN : Incorrect APN found Setting Correct APN'");
				SetAPN(simNum);
				Check_ExistPPP();

				sleep(2);
				system(cmd1);
				sleep(12);
				CopyPID();
				indexer=1;
				ppp_flag=1;
				//break;
				return 0;
				
			} 
		//pingFlag=1; // Flag is 1 for Vodafone
}

}
/*############################################# Searching for  Registeration  #############################################*/
else if(strcmp(modem_config.nwstate,"2") == 0)
{
printf("Searching For Registration !!!! \n");
system("logger 'PPP0 : NW_RG_STATE : Searching'");
system(cmd3);
sleep(10);
continue;

}
/*############################################# Not Registered  #############################################*/

else if(strcmp(modem_config.nwstate,"0") == 0)
{
printf("Registration faield \n");
system("logger 'PPP0 : NW_RG_STATE : Not Registered'");
system(cmd3);
sleep(20);
continue;
}
/*############################################# Registeration Denied  #############################################*/
else if(strcmp(modem_config.nwstate,"3") == 0)
{
printf("Registration Denied \n");
system("logger 'PPP0 : NW_RG_STATE : Registeration Denied'");
system(cmd3);
sleep(20);
continue;
}

/*############################################# Not Registered State  #############################################*/
else
{
system("logger 'PPP0 : NW_RG_STATE : Couldn't Parse Modem Response'");
system(cmd3);
sleep(20);
continue;
}
/*############################################# Adding Routes  #############################################*/

/*

sleep(3);
system(cmd4); // Add the route-1 based on Operator
system(cmd5); // Add the route-2 based on Operator
system(cmd6); // Add the route-3 based on Operator
system(cmd7); // Add the route-4 based on Operator
sleep(2);
printf("#### Adding Routes ####\n");
*/

/*################################################ PING TEST FOR AIRTEL  ####################################################*/
/*
if (pingFlag == 2)
{
while(!system("ping -I ppp1 -c5 10.66.30.10 -i 30")) // Ping the Airtel Primary Router at CRIS END
    {
        printf ("\n Primary Connection Exists\n");
	system("logger 'PPP1 : E2E_STATE : Airtel Primary Connection Alive'");
	flag = 1;
	printf("Airtel Connection Alive\n");
        sleep(5);
    }
	system("logger 'PPP1 : E2E_STATE : Airtel Primary Router Ping Failed'");
	printf("Entering Secondary Ping-Check\n");
while(!system("ping -I ppp1 -c5 10.66.30.14 -i 30")) // Ping the Airtel Secondary Router at CRIS END
    {
        printf ("\n Secondary Connection Exists\n");
	system("logger 'PPP1 : E2E_STATE : Airtel Secondary Connection Alive'");
	flag = 1;
	printf("Airtel Connection Alive\n");
        sleep(5);
    }
	system("logger 'PPP1 : E2E_STATE : Airtel Secondary Router Ping Failed'");


}
*/

/*################################################ PING TEST FOR VODAFONE-IDEA  ####################################################*/

/*
else if (pingFlag == 1)
{

while(!system("ping -I ppp1 -c5 10.66.30.17 -i 30")) // Ping the Vodafone-Idea Primary Router at CRIS END
    {
        printf ("\n Primary Conection Exists\n");
	system("logger 'PPP1 : E2E_STATE : Vodafone-IDEA Primary Connection Alive'");
	flag = 1;
	printf("Vodafone-Idea Connection Alive\n");
        sleep(5);
    }
	printf("Entering Secondary Ping-Check\n");
	system("logger 'PPP1 : E2E_STATE : Vodafone-IDEA Primary Router Ping Failed'");
while(!system("ping -I ppp1 -c5 10.66.30.21 -i 30")) // Ping the Vodafone-Idea Secondary Router at CRIS END
    {
        printf ("\n Secondary Connection Exists\n");
	system("logger 'PPP1 : E2E_STATE : Vodafone-IDEA Secondary Connection Alive'");
	flag = 1;
	printf("Vodafone-Idea Connection Alive\n");
        sleep(5);
    }
	printf("Secondary Router Ping Failed \n");
	system("logger 'PPP1 : E2E_STATE : Vodafone-IDEA Secondary Router Ping Failed'");
}


	sleep(2);

*/

/*########################################### PING FAILED KILL PPPD DAEMON AND RETRY #############################################*/

/*
 printf ("\n Not reachable \n");


printf("#######=======> Killing PPPD daemon <=======#######\n");
	system("logger 'PPP1 : PPPD_STATE : Killing PPP Daemon'");
ret = killdaemon();
strcpy(modem_config.nwstate,"0");
if(ret == 0)
{
printf("PPPD daemon killed \n");
	system("logger 'PPP1 : PPPD_STATE : PPP Daemon Killed'");
sleep (10);
ReleasePort(); // Sending +++ to release the AT Port
}
else
{
printf("No PPPD running \n");
	system("logger 'PPP1 : PPPD_KILL_STATE : No PPP Daemon Running'");
}
sleep(10);
*/

printf("#####INSIDE LOOP######\n");
}

printf("#########OUT OF LOOP########\n");
return 0;
}

/*----------########################################### MAIN END ###############################################--------- */


