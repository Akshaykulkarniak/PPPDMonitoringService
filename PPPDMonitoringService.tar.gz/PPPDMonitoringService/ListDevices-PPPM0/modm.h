#ifndef MODM_H_INCLUDE_GUARD
#define MODM_H_INCLUDE_GUARD

typedef struct 
{
        char oper_name[40]; // stores operator info AT+COPS?
        char rat[1];  // stores Radio Access technology AT+COPS?
        char sigStr[2]; // stores signal strength AT+CSQ
        char simState[100]; // stores sim state AT+CPIN?
        char nwstate[100]; // stores network registration state AT+CREG?
	char pdpstate[60];
	char operID[5]; // stores operator ID from crsm
}modem_mgt;

char * Get_Sim_State();

void Read_Sim_State(char *Rspn,modem_mgt *info);

char * Get_Signal_Strength();

//char * Read_Signal_Strength(char *Rspn);
void Read_Signal_Strength(char *Rspn,modem_mgt *info);


//void Get_OperInfoCMD(char *OperCmd);

char * Get_OperInfoCMD();

//char * Get_OperInfoRspn(char *Rspn);
void Get_OperInfoRspn(char *Rspn,modem_mgt *info);

char * Get_RegState();
void Read_NtwRegState(char *Rspn,modem_mgt *info);


char * Get_PdpCont();
void Read_PdpCont(char *Rspn,modem_mgt *info,int simNum);

char * Set_PdpCont();

void Get_OperID(char *Rspn,modem_mgt *info);


char * Get_OperIDCMD();


#endif // INCLUDE_GUARD

