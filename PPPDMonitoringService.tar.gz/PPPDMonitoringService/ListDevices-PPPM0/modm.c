/******************************************************************************************************
 * AUTHOR : ASK
 * COMPANY : Syratron Technologies Pvt Ltd / Sierra Wireless
 * FILE NAME : modm.c
 * APPLICATION : AT-Parser  
 * DATE : 25/04/2020
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, 
 * copies of the Software
 ******************************************************************************************************/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdbool.h>
#include "modm.h"
#include<syslog.h>

#define comment 0

/************************************************************************
Get the Service provider ID

Get_OperID()

|||||||||||||||||||||||||||||||||||||||||||||

 ####0061####  => AIRTEL
 ####0056####  => VODAFONE-IDEA
 ####004A####  => JIO

|||||||||||||||||||||||||||||||||||||||||||||

************************************************************************/



void Get_OperID(char *Rspn,modem_mgt *info)
{
char buff1[5120]="\0";
char value[5120]="\0";
printf("Inside buffer:: %s\n",Rspn);
strcpy(buff1,Rspn);
char *buff = strstr(buff1,"+CRSM:");
if (buff != NULL)
{
#if comment 
printf("buffer has := %s",buff1);
#endif
strncpy(value,buff+14,4);
#if comment 
printf("OPERATOR ID VALUE HAS %s\n",value);
#endif
strcpy(info->operID,value);
}

}



/************************************************************************
Get the Service provider ID CMD

Get_OperIDCMD()
************************************************************************/

char * Get_OperIDCMD()
{
char * OperIDCmd = "AT+CRSM=176,28486,0,0,2\n";
#if comment 
printf("Sending the buffer with %s\n",OperIDCmd);
#endif
return OperIDCmd;
}



/*************************************************************************
Set the PDP context

Set_PdpCont()
************************************************************************/


char * Set_PdpCont()
{
char * PdpContCmd = "AT+CGDCONT=1,\"IPV4V6\",\"airtelgprs.com\"\r";
#if comment 
printf("Sending the buffer with %s\n",PdpContCmd);
#endif
return PdpContCmd;
}




/*************************************************************************
Get the PDP context CMD
 
Get_PdpCont()
************************************************************************/

char * Get_PdpCont()
{
char * PdpContCmd = "AT+CGDCONT?\r";
#if comment 
printf("Sending the buffer with %s\n",PdpContCmd);
#endif
return PdpContCmd;
}

/*************************************************************************
Read the APN from PDP context

Read_PdpCont()
************************************************************************/



void Read_PdpCont(char *Rspn,modem_mgt *info,int simNum)  //1st sim is Vodafone and 2nd sim is Airtel
{
char buff1[5120]="\0";
char value[5120]="\0";
//char state[1];
#if comment 
printf("simNum is @#%d#@\n",simNum);
printf("Inside buffer:: %s\n",Rspn);
#endif
strcpy(buff1,Rspn);
char *buff = strstr(buff1,"+CGDCONT:");
if (buff != NULL)
{
#if comment 
printf("buffer has := ##%s##",buff);
#endif
if(simNum == 1)
{
#if comment 
printf("SIM-VODAFONE\n");
#endif
strncpy(value,buff+22,18);
#if comment 
printf("VALUE HAS %s\n",value);
#endif
		if (strcmp(value,"IOT.CRISRTIS.CO.IN") == 0) // Check if Vodafone APN is set properly
			{

			strcpy(info->pdpstate,value);
			printf("APN is %s\n",value);
			}
}
else if (simNum == 2)
{
printf("SIM-AIRTEL\n");
strncpy(value,buff+22,12); // 14-09-2020 Changed from 9 to 12 due to change in APN as suggested by Pankaj
#if comment 
printf("VALUE HAS %s\n",value);
#endif
		if (strcmp(value,"CRISRTIS.COM") == 0) // Check if Airtel APN is set properly (14-09-2020 Airtel APN changed from CRIS1.COM to CRISRTIS.COM according to Pankaj's suggestion)
			{
			strcpy(info->pdpstate,value);
		#if comment 
			printf("APN is %s\n",value);
		#endif
			}
}
else
{
		#if comment 
printf("WRONG APN Set \n");
		#endif
strcpy(info->pdpstate,value);
		#if comment 
printf("Creating PDP Context 1 \n");
		#endif
}
}
}





/*************************************************************************
Get the Registration state

Get_RegState()
************************************************************************/
char * Get_RegState()
{
char * NtwRegCmd = "AT+CREG?\r";
		#if comment 
printf("Sending the buffer with %s\n",NtwRegCmd);
		#endif
return NtwRegCmd;
}


void Read_NtwRegState(char *Rspn,modem_mgt *info)
{
char buff1[5120]="\0";
char value[5120]="\0";


		#if comment 
printf("RNWRG-Inside buffer:: %s\n",Rspn);
		#endif
strcpy(buff1,Rspn);
char *buff = strstr(buff1,"+CREG:");
if (buff != NULL)
{
		#if comment 
printf("buffer has := %s",buff);
		#endif
strncpy(value,buff+9,1);
		#if comment 
printf("\n VALUE HAS %s\n",value);
		#endif
if (value[0] == '1')
{
strncpy(info->nwstate,value,1);
printf("The Sim is Registered to Home network and value is %s\n",value);
}
else
{
strncpy(info->nwstate,value,1); //Need to handle the Error atleast a logger is necesssary
}
}

}


/*************************************************************************
Get the Sim state

Get_Sim_State()
************************************************************************/


char * Get_Sim_State()
{
 char * simStateCmd = "AT+CPIN?\r";

printf("Filling the buffer with %s\n",simStateCmd);
return simStateCmd;
}


/*************************************************************************
Read the Sim state

Read_Sim_State()
************************************************************************/


void Read_Sim_State(char *Rspn,modem_mgt *info)
{
char state[5120]="\0";
char buff1[5120]="\0";
printf("response buffer:: %s\n",Rspn);
strcpy(buff1,Rspn);
char *buff = strstr(buff1,"+CPIN:");
system("logger 'Entering Read-Sim'");
if (buff != NULL)
{
printf("buffer has :: %s",buff+7);
strncpy(state,buff+7,5);
printf("The sim state is %s\n",state);


	if(!strcmp(state,"READY"))
	{
		strcpy(info->simState,"Present");
	memset(buff1, 0, sizeof(buff1));
	memset(state, 0, sizeof(state));
		printf("Sim Present\n");
	}
	else 
		{
		strcpy(info->simState,"Absent");
		printf("Sim Absent\n");
	memset(buff1, 0, sizeof(buff1));
	memset(state, 0, sizeof(state));
		}
}
else
{
		strcpy(info->simState,"Absent");
		printf("Sim Absent\n");
	memset(buff1, 0, sizeof(buff1));
	memset(state, 0, sizeof(state));
}


}


/*************************************************************************
Get the Signal Strength

Get_Signal_Strength()
************************************************************************/

char * Get_Signal_Strength()
{
char * SigStrCmd = "AT+CSQ\r";
printf("Filling the buffer with %s\n",SigStrCmd);
return SigStrCmd;
}

/********************************************************************************************************

<rssi> 				Received signal strength indication
0				-113 dBm or less
1 – 30				-111 to -53 dBm
31				-51 dBm or greater
99 				Not known or not detectable

*********************************************************************************************************/

void Read_Signal_Strength(char *Rspn,modem_mgt *info)
{

char buff1[5120]="\0";
char value[5120]="\0";
//printf("Inside Rspn fun %s\n",Rspn);
//------------------------------


printf("Inside buffer:: %s\n",Rspn);
strcpy(buff1,Rspn);
char *buff = strstr(buff1,"+CSQ:");
if (buff != NULL)
{
printf("buffer has :: %s",buff+5);
strncpy(value,buff+5,3);
if (strcmp(value," 99") == 0)
{
//strcpy(value,"0");
strcpy(info->sigStr,value);
openlog("SIGNAL_STRENGTH", LOG_PID, LOG_USER);
syslog(LOG_INFO, "Antenna Failure : err %s",value);
printf("Please check Antenna connection\n");
}
else
{
strcpy(info->sigStr,value);
//printf("The Signal Strength is %s\n",value);
      openlog("SIGNAL_STRENGTH", LOG_PID, LOG_USER);
      syslog(LOG_INFO, "SignalStrength is %s",value);
      closelog();
    }

//-----------------------------
/*
strcpy(buff1,Rspn);
buff1[sizeof(buff1)+1]='\0';
char *token = strtok(buff1,":  ");
token = strtok(NULL,",");
strcpy(value,token); 
strcpy(info->sigStr,value);
printf("In SigStr we have %s\n",value);
printf("HERE we have Signal Strength as %s\n",info->sigStr);
*/
//-------------------------------
}
}


char * Get_OperInfoCMD()
{
	char *OperCmd = "AT+COPS?\r";	
	printf("Filling the buffer with %s\n",OperCmd);
	return OperCmd;
}


void Get_OperInfoRspn(char *Rspn,modem_mgt *info)
{

	char buff1[5120]="\0";
	char name[5120]="\0";
	char rat[1]="\0";
	//char chk[30]="AT+COPS?\r\n+COPS: 0,0,"",0\r\nOK"; // ERROR CASE
	printf("We have parsed %s !!!!! \n",Rspn);
	printf("The size is %d\n",strlen(Rspn)); 
	if(strlen(Rspn) > 34 )
	{
	printf("COMPARED EQUAL\n");
		strcpy(buff1,Rspn);
		buff1[sizeof(buff1)+1]='\0';
		char *token = strtok(buff1,"\"");
		token = strtok(NULL,"\"");
		strcpy(name,token); 
		strcpy(info->oper_name,name);
		token=strtok(NULL,",");
		strcpy(rat,token);
		strcpy(info->rat,rat);
		//printf("In rat we have %s\n",rat);
		printf("HERE we have opername as %s\n",info->oper_name);
		printf("HERE we have RAT as %s\n",info->rat);
	}
	else
	{
		printf("Unknown state\n");
		printf("Please check sim Insertion\n");
		strcpy(info->oper_name,"Unknown");
		strcpy(info->rat,"0");
	}
}



int main()
{
printf("Welcome to modemmanagement lib\n");
}
